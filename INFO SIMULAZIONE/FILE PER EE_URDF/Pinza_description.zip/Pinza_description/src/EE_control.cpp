#include "ros/ros.h" 
#include "sensor_msgs/JointState.h"

int main(int argc, char **argv) {

	ros::init(argc, argv,"nefertari_publisher");
	ros::NodeHandle nh;
	ros::Publisher jointStatesPublisher = nh.advertise<sensor_msgs::JointState>("/joint_states", 1);

	ros::Rate rate(50);  //100 hz

	

	/*msg.name.push_back("Avvitatore");
    msg.position.push_back(0.7);  
    msg.name.push_back("PinzaSup");
    msg.position.push_back(0); 
	msg.name.push_back("PinzaInf");
    msg.position.push_back(0); */

	while (ros::ok()){
		sensor_msgs::JointState msg;
	    msg.position.push_back(0.1); 
		
        msg.position.push_back(0);  
		
		jointStatesPublisher.publish(msg); //pubblica poi aggiorna il valore
		rate.sleep();
	}
	return 0;
}
